import { useState, useMemo } from "react";

const PRODUCTS = [
  { id: 1, name: "প্রিমিয়াম কটন পাঞ্জাবি", price: 1200, originalPrice: 1800, category: "পোশাক", rating: 4.5, reviews: 128, image: "👘", badge: "সেরা বিক্রি", inStock: true, description: "উচ্চমানের কটন কাপড়ে তৈরি আরামদায়ক পাঞ্জাবি। ঈদ ও উৎসবের জন্য আদর্শ।" },
  { id: 2, name: "স্মার্টফোন কেস (ট্রান্সপারেন্ট)", price: 299, originalPrice: 499, category: "ইলেকট্রনিক্স", rating: 4.2, reviews: 89, image: "📱", badge: "নতুন", inStock: true, description: "টেকসই ট্রান্সপারেন্ট ব্যাক কভার। সব মডেলে পাওয়া যায়।" },
  { id: 3, name: "হ্যান্ডমেড চামড়ার ব্যাগ", price: 3500, originalPrice: 4500, category: "ব্যাগ", rating: 4.8, reviews: 54, image: "👜", badge: "প্রিমিয়াম", inStock: true, description: "খাঁটি চামড়ায় হাতে তৈরি শপিং ব্যাগ। দীর্ঘস্থায়ী ও স্টাইলিশ।" },
  { id: 4, name: "বাসমতি চাল ৫ কেজি", price: 650, originalPrice: 750, category: "খাদ্য", rating: 4.6, reviews: 203, image: "🌾", badge: "অফার", inStock: true, description: "প্রিমিয়াম মানের বাসমতি চাল। পোলাও ও বিরিয়ানির জন্য পারফেক্ট।" },
  { id: 5, name: "ওয়্যারলেস ইয়ারবাড", price: 2200, originalPrice: 3000, category: "ইলেকট্রনিক্স", rating: 4.4, reviews: 167, image: "🎧", badge: "হট ডিল", inStock: true, description: "নয়েজ ক্যান্সেলিং ওয়্যারলেস ইয়ারবাড। ৲০ ঘণ্টা ব্যাটারি লাইফ।" },
  { id: 6, name: "অর্গানিক নারিকেল তেল", price: 380, originalPrice: 500, category: "সৌন্দর্য", rating: 4.7, reviews: 91, image: "🥥", badge: "অর্গানিক", inStock: false, description: "১০০% অর্গানিক ঠান্ডা চাপা নারিকেল তেল। চুল ও ত্বকের যত্নে অতুলনীয়।" },
  { id: 7, name: "কিডস স্পোর্টস জুতো", price: 890, originalPrice: 1200, category: "জুতো", rating: 4.3, reviews: 76, image: "👟", badge: "শিশু", inStock: true, description: "আরামদায়ক স্পোর্টস জুতো। টেকসই সোল ও হালকা ওজন।" },
  { id: 8, name: "ড্রাই ফ্রুট গিফট বক্স", price: 1500, originalPrice: 1800, category: "খাদ্য", rating: 4.9, reviews: 42, image: "🎁", badge: "উপহার", inStock: true, description: "বিভিন্ন ধরনের ড্রাই ফ্রুটের সমাহার। বিশেষ উপলক্ষে আদর্শ উপহার।" },
];

const CATEGORIES = ["সব", "পোশাক", "ইলেকট্রনিক্স", "ব্যাগ", "খাদ্য", "সৌন্দর্য", "জুতো"];

const ORDERS = [
  { id: "ORD-2024-001", date: "১৫ জুন ২০২৪", status: "ডেলিভারি হয়েছে", total: 3799, items: ["প্রিমিয়াম কটন পাঞ্জাবি", "ওয়্যারলেস ইয়ারবাড"], statusColor: "#16a34a" },
  { id: "ORD-2024-002", date: "১৮ জুন ২০২৪", status: "পথে আছে", total: 1150, items: ["বাসমতি চাল ৫ কেজি", "অর্গানিক নারিকেল তেল"], statusColor: "#ea580c" },
  { id: "ORD-2024-003", date: "২০ জুন ২০২৪", status: "প্রক্রিয়াধীন", total: 890, items: ["কিডস স্পোর্টস জুতো"], statusColor: "#7c3aed" },
];

function StarRating({ rating }) {
  return (
    <span style={{ color: "#f59e0b", fontSize: 12 }}>
      {"★".repeat(Math.floor(rating))}{"☆".repeat(5 - Math.floor(rating))}
      <span style={{ color: "#6b7280", marginLeft: 4 }}>{rating}</span>
    </span>
  );
}

function Badge({ text }) {
  const colors = {
    "সেরা বিক্রি": "#dc2626", "নতুন": "#2563eb", "প্রিমিয়াম": "#7c3aed",
    "অফার": "#ea580c", "হট ডিল": "#dc2626", "অর্গানিক": "#16a34a",
    "শিশু": "#0891b2", "উপহার": "#db2777",
  };
  return (
    <span style={{
      background: colors[text] || "#6b7280",
      color: "#fff", fontSize: 9, fontWeight: 700,
      padding: "2px 6px", borderRadius: 8,
    }}>{text}</span>
  );
}

export default function App() {
  const [tab, setTab] = useState("home");
  const [cart, setCart] = useState([]);
  const [wishlist, setWishlist] = useState([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("সব");
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [notification, setNotification] = useState(null);
  const [sortBy, setSortBy] = useState("default");

  const showNotif = (msg) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 2000);
  };

  const addToCart = (product) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === product.id);
      if (existing) return prev.map(i => i.id === product.id ? { ...i, qty: i.qty + 1 } : i);
      return [...prev, { ...product, qty: 1 }];
    });
    showNotif(`✅ ${product.name} কার্টে যোগ হয়েছে`);
  };

  const removeFromCart = (id) => setCart(prev => prev.filter(i => i.id !== id));
  const updateQty = (id, delta) => {
    setCart(prev => prev.map(i => i.id === id ? { ...i, qty: Math.max(1, i.qty + delta) } : i).filter(i => i.qty > 0));
  };

  const toggleWishlist = (product) => {
    const inWishlist = wishlist.find(i => i.id === product.id);
    if (inWishlist) { setWishlist(prev => prev.filter(i => i.id !== product.id)); showNotif("💔 উইশলিস্ট থেকে সরানো হয়েছে"); }
    else { setWishlist(prev => [...prev, product]); showNotif("❤️ উইশলিস্টে যোগ হয়েছে"); }
  };

  const cartTotal = cart.reduce((sum, i) => sum + i.price * i.qty, 0);
  const cartCount = cart.reduce((sum, i) => sum + i.qty, 0);

  const filteredProducts = useMemo(() => {
    let p = PRODUCTS.filter(p =>
      (category === "সব" || p.category === category) &&
      (search === "" || p.name.toLowerCase().includes(search.toLowerCase()) || p.category.includes(search))
    );
    if (sortBy === "price-asc") p = [...p].sort((a, b) => a.price - b.price);
    if (sortBy === "price-desc") p = [...p].sort((a, b) => b.price - a.price);
    if (sortBy === "rating") p = [...p].sort((a, b) => b.rating - a.rating);
    return p;
  }, [category, search, sortBy]);

  const placeOrder = () => {
    setOrderPlaced(true);
    setCart([]);
    setTimeout(() => { setOrderPlaced(false); setTab("orders"); }, 2500);
  };

  const s = {
    app: { maxWidth: 400, margin: "0 auto", minHeight: "100vh", background: "#f8fafc", fontFamily: "'Hind Siliguri', 'Noto Sans Bengali', sans-serif", position: "relative", overflow: "hidden" },
    header: { background: "linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%)", padding: "16px", paddingTop: 24, color: "#fff" },
    headerTop: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
    logo: { fontSize: 20, fontWeight: 800, letterSpacing: -0.5 },
    iconBtn: { background: "rgba(255,255,255,0.15)", border: "none", borderRadius: 10, width: 38, height: 38, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#fff", fontSize: 18, position: "relative" },
    badge: { position: "absolute", top: -4, right: -4, background: "#ef4444", color: "#fff", borderRadius: "50%", width: 18, height: 18, fontSize: 10, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700 },
    searchBar: { display: "flex", gap: 8, background: "#fff", borderRadius: 12, padding: "10px 14px", alignItems: "center" },
    searchInput: { flex: 1, border: "none", outline: "none", fontSize: 14, fontFamily: "inherit", color: "#1e293b" },
    content: { padding: "0 0 80px 0", overflowY: "auto", maxHeight: "calc(100vh - 160px)" },
    bottomNav: { position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 400, background: "#fff", borderTop: "1px solid #e2e8f0", display: "flex", justifyContent: "space-around", padding: "8px 0 16px", zIndex: 50 },
    navBtn: (active) => ({ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 2, border: "none", background: "none", cursor: "pointer", color: active ? "#2563eb" : "#94a3b8", fontSize: 10, fontFamily: "inherit", fontWeight: active ? 700 : 400 }),
    navIcon: { fontSize: 22 },
    prodCard: { background: "#fff", borderRadius: 16, overflow: "hidden", boxShadow: "0 1px 4px rgba(0,0,0,0.08)" },
    prodEmoji: { fontSize: 52, display: "flex", alignItems: "center", justifyContent: "center", background: "#f1f5f9", height: 110, borderRadius: "12px 12px 0 0" },
    prodInfo: { padding: "10px 12px 12px" },
    price: { fontSize: 17, fontWeight: 800, color: "#1e3a5f" },
    origPrice: { fontSize: 12, color: "#94a3b8", textDecoration: "line-through", marginLeft: 4 },
    addBtn: (inStock) => ({ width: "100%", marginTop: 8, background: inStock ? "linear-gradient(135deg, #2563eb, #1e40af)" : "#e2e8f0", color: inStock ? "#fff" : "#94a3b8", border: "none", borderRadius: 10, padding: "8px 0", fontSize: 13, fontWeight: 700, cursor: inStock ? "pointer" : "not-allowed", fontFamily: "inherit" }),
    section: { padding: "16px 16px 0" },
    sectionTitle: { fontSize: 17, fontWeight: 800, color: "#1e293b", marginBottom: 12 },
    banner: { margin: "16px 16px 0", borderRadius: 16, background: "linear-gradient(135deg, #f59e0b, #ef4444)", padding: "20px 20px", color: "#fff" },
    catScroll: { display: "flex", gap: 8, overflowX: "auto", padding: "12px 16px 0", scrollbarWidth: "none" },
    catBtn: (active) => ({ flexShrink: 0, padding: "7px 16px", borderRadius: 20, border: "none", cursor: "pointer", fontSize: 13, fontWeight: active ? 700 : 500, background: active ? "#2563eb" : "#fff", color: active ? "#fff" : "#64748b", boxShadow: "0 1px 3px rgba(0,0,0,0.1)", fontFamily: "inherit" }),
    cartItem: { display: "flex", gap: 12, background: "#fff", borderRadius: 14, padding: "12px", marginBottom: 10 },
    qtyBtn: { width: 28, height: 28, borderRadius: 8, border: "1px solid #e2e8f0", background: "#f8fafc", cursor: "pointer", fontSize: 16, display: "flex", alignItems: "center", justifyContent: "center" },
    orderCard: { background: "#fff", borderRadius: 14, padding: "14px", marginBottom: 10 },
    notif: { position: "fixed", top: 20, left: "50%", transform: "translateX(-50%)", background: "#1e293b", color: "#fff", padding: "10px 20px", borderRadius: 30, fontSize: 13, fontWeight: 600, zIndex: 999, whiteSpace: "nowrap", boxShadow: "0 4px 20px rgba(0,0,0,0.2)" },
  };

  if (selectedProduct) {
    const p = selectedProduct;
    const inWishlist = wishlist.find(i => i.id === p.id);
    const discount = Math.round((1 - p.price / p.originalPrice) * 100);
    return (
      <div style={s.app}>
        {notification && <div style={s.notif}>{notification}</div>}
        <div style={{ background: "#fff", padding: "16px", display: "flex", alignItems: "center", gap: 12, borderBottom: "1px solid #f1f5f9" }}>
          <button onClick={() => setSelectedProduct(null)} style={{ ...s.iconBtn, background: "#f1f5f9", color: "#1e293b" }}>←</button>
          <span style={{ fontWeight: 700, fontSize: 16 }}>পণ্যের বিবরণ</span>
          <button onClick={() => toggleWishlist(p)} style={{ ...s.iconBtn, background: "#f1f5f9", color: inWishlist ? "#ef4444" : "#94a3b8", marginLeft: "auto" }}>
            {inWishlist ? "❤️" : "🤍"}
          </button>
        </div>
        <div style={{ background: "#f8fafc", height: 220, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 90 }}>{p.image}</div>
        <div style={{ padding: 20, background: "#fff" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
            <Badge text={p.badge} />
            <span style={{ fontSize: 12, color: "#64748b" }}>{p.category}</span>
          </div>
          <div style={{ fontSize: 20, fontWeight: 800, color: "#1e293b", marginBottom: 8 }}>{p.name}</div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
            <span style={{ fontSize: 26, fontWeight: 800, color: "#1e3a5f" }}>৳{p.price.toLocaleString("bn-BD")}</span>
            <span style={{ fontSize: 16, color: "#94a3b8", textDecoration: "line-through" }}>৳{p.originalPrice.toLocaleString("bn-BD")}</span>
            <span style={{ background: "#dcfce7", color: "#16a34a", fontSize: 12, fontWeight: 700, padding: "2px 8px", borderRadius: 8 }}>{discount}% ছাড়</span>
          </div>
          <div style={{ marginBottom: 12 }}><StarRating rating={p.rating} /> <span style={{ fontSize: 12, color: "#94a3b8" }}>({p.reviews} রিভিউ)</span></div>
          <div style={{ fontSize: 14, color: "#475569", lineHeight: 1.8, background: "#f8fafc", borderRadius: 12, padding: "12px 14px", marginBottom: 16 }}>{p.description}</div>
          {!p.inStock && <div style={{ background: "#fef2f2", color: "#dc2626", padding: "8px 14px", borderRadius: 10, fontSize: 13, fontWeight: 600, marginBottom: 12 }}>⚠️ স্টক শেষ হয়ে গেছে</div>}
          <button onClick={() => { addToCart(p); setSelectedProduct(null); }} disabled={!p.inStock} style={{ ...s.addBtn(p.inStock), padding: "14px 0", fontSize: 15, borderRadius: 14 }}>
            {p.inStock ? "🛒 কার্টে যোগ করুন" : "স্টক নেই"}
          </button>
        </div>
      </div>
    );
  }

  if (orderPlaced) {
    return (
      <div style={{ ...s.app, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 16 }}>
        <div style={{ fontSize: 80 }}>🎉</div>
        <div style={{ fontSize: 22, fontWeight: 800, color: "#1e293b" }}>অর্ডার সম্পন্ন!</div>
        <div style={{ fontSize: 14, color: "#64748b" }}>আপনার অর্ডার সফলভাবে দেওয়া হয়েছে</div>
      </div>
    );
  }

  return (
    <div style={s.app}>
      {notification && <div style={s.notif}>{notification}</div>}

      {/* Header */}
      <div style={s.header}>
        <div style={s.headerTop}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect width="36" height="36" rx="10" fill="white" fillOpacity="0.2"/>
              <path d="M10 13h16l-2 10H12L10 13z" fill="white" fillOpacity="0.9"/>
              <path d="M10 13l-1.5-4H6" stroke="white" strokeWidth="1.8" strokeLinecap="round"/>
              <circle cx="14" cy="25.5" r="1.5" fill="white"/>
              <circle cx="22" cy="25.5" r="1.5" fill="white"/>
              <path d="M13 17h10M12.5 20h11" stroke="#2563eb" strokeWidth="1.4" strokeLinecap="round"/>
            </svg>
            <div style={s.logo}>BazarBD</div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={() => setTab("wishlist")} style={s.iconBtn}>
              ❤️
              {wishlist.length > 0 && <span style={s.badge}>{wishlist.length}</span>}
            </button>
            <button onClick={() => setTab("cart")} style={s.iconBtn}>
              🛒
              {cartCount > 0 && <span style={s.badge}>{cartCount}</span>}
            </button>
          </div>
        </div>
        {(tab === "home" || tab === "search") && (
          <div style={s.searchBar}>
            <span style={{ fontSize: 16, color: "#94a3b8" }}>🔍</span>
            <input
              style={s.searchInput}
              placeholder="পণ্য খুঁজুন..."
              value={search}
              onChange={e => { setSearch(e.target.value); setTab("search"); }}
              onFocus={() => setTab("search")}
            />
            {search && <button onClick={() => setSearch("")} style={{ border: "none", background: "none", cursor: "pointer", color: "#94a3b8", fontSize: 16 }}>✕</button>}
          </div>
        )}
      </div>

      {/* Content */}
      <div style={s.content}>
        {/* HOME TAB */}
        {tab === "home" && (
          <>
            {/* Banner */}
            <div style={s.banner}>
              <div style={{ fontSize: 11, fontWeight: 600, opacity: 0.85, marginBottom: 4 }}>🔥 সীমিত সময়ের অফার</div>
              <div style={{ fontSize: 22, fontWeight: 800, marginBottom: 4 }}>ঈদ সেল শুরু!</div>
              <div style={{ fontSize: 14, opacity: 0.9, marginBottom: 12 }}>সর্বোচ্চ ৫০% পর্যন্ত ছাড় পাচ্ছেন</div>
              <button onClick={() => setTab("search")} style={{ background: "#fff", color: "#ef4444", border: "none", borderRadius: 10, padding: "8px 20px", fontWeight: 700, fontSize: 13, cursor: "pointer", fontFamily: "inherit" }}>এখনই দেখুন →</button>
            </div>

            {/* Categories */}
            <div style={s.catScroll}>
              {CATEGORIES.map(c => (
                <button key={c} onClick={() => { setCategory(c); setTab("search"); }} style={s.catBtn(false)}>{c}</button>
              ))}
            </div>

            {/* Featured */}
            <div style={s.section}>
              <div style={s.sectionTitle}>✨ বিশেষ অফার</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                {PRODUCTS.filter(p => p.inStock).slice(0, 4).map(p => (
                  <div key={p.id} style={s.prodCard} onClick={() => setSelectedProduct(p)}>
                    <div style={s.prodEmoji}>{p.image}</div>
                    <div style={s.prodInfo}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
                        <span style={{ fontSize: 12, color: "#64748b" }}>{p.category}</span>
                        <Badge text={p.badge} />
                      </div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: "#1e293b", marginBottom: 4, lineHeight: 1.3 }}>{p.name}</div>
                      <StarRating rating={p.rating} />
                      <div style={{ marginTop: 4 }}>
                        <span style={s.price}>৳{p.price.toLocaleString("bn-BD")}</span>
                        <span style={s.origPrice}>৳{p.originalPrice}</span>
                      </div>
                      <button onClick={e => { e.stopPropagation(); addToCart(p); }} style={s.addBtn(true)}>+ কার্টে যোগ</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* All products */}
            <div style={s.section}>
              <div style={s.sectionTitle}>🛍️ সব পণ্য</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                {PRODUCTS.slice(4).map(p => (
                  <div key={p.id} style={{ ...s.prodCard, opacity: p.inStock ? 1 : 0.7 }} onClick={() => setSelectedProduct(p)}>
                    <div style={s.prodEmoji}>{p.image}</div>
                    <div style={s.prodInfo}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
                        <span style={{ fontSize: 12, color: "#64748b" }}>{p.category}</span>
                        <Badge text={p.badge} />
                      </div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: "#1e293b", marginBottom: 4, lineHeight: 1.3 }}>{p.name}</div>
                      <StarRating rating={p.rating} />
                      <div style={{ marginTop: 4 }}>
                        <span style={s.price}>৳{p.price.toLocaleString("bn-BD")}</span>
                        <span style={s.origPrice}>৳{p.originalPrice}</span>
                      </div>
                      <button onClick={e => { e.stopPropagation(); if (p.inStock) addToCart(p); }} style={s.addBtn(p.inStock)}>
                        {p.inStock ? "+ কার্টে যোগ" : "স্টক নেই"}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* SEARCH TAB */}
        {tab === "search" && (
          <>
            <div style={s.catScroll}>
              {CATEGORIES.map(c => (
                <button key={c} onClick={() => setCategory(c)} style={s.catBtn(category === c)}>{c}</button>
              ))}
            </div>
            <div style={{ padding: "12px 16px 0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: 13, color: "#64748b" }}>{filteredProducts.length}টি পণ্য পাওয়া গেছে</span>
              <select value={sortBy} onChange={e => setSortBy(e.target.value)} style={{ border: "1px solid #e2e8f0", borderRadius: 8, padding: "4px 8px", fontSize: 12, fontFamily: "inherit", color: "#475569", background: "#fff" }}>
                <option value="default">ডিফল্ট</option>
                <option value="price-asc">দাম: কম থেকে বেশি</option>
                <option value="price-desc">দাম: বেশি থেকে কম</option>
                <option value="rating">রেটিং</option>
              </select>
            </div>
            <div style={{ ...s.section, paddingTop: 12 }}>
              {filteredProducts.length === 0 ? (
                <div style={{ textAlign: "center", padding: "60px 20px", color: "#94a3b8" }}>
                  <div style={{ fontSize: 48, marginBottom: 12 }}>🔍</div>
                  <div style={{ fontSize: 16, fontWeight: 600 }}>কোনো পণ্য পাওয়া যায়নি</div>
                  <div style={{ fontSize: 13, marginTop: 4 }}>অন্য কিছু খুঁজে দেখুন</div>
                </div>
              ) : (
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  {filteredProducts.map(p => (
                    <div key={p.id} style={{ ...s.prodCard, opacity: p.inStock ? 1 : 0.7 }} onClick={() => setSelectedProduct(p)}>
                      <div style={s.prodEmoji}>{p.image}</div>
                      <div style={s.prodInfo}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
                          <span style={{ fontSize: 12, color: "#64748b" }}>{p.category}</span>
                          <Badge text={p.badge} />
                        </div>
                        <div style={{ fontSize: 13, fontWeight: 700, color: "#1e293b", marginBottom: 4, lineHeight: 1.3 }}>{p.name}</div>
                        <StarRating rating={p.rating} />
                        <div style={{ marginTop: 4 }}>
                          <span style={s.price}>৳{p.price.toLocaleString("bn-BD")}</span>
                          <span style={s.origPrice}>৳{p.originalPrice}</span>
                        </div>
                        <button onClick={e => { e.stopPropagation(); if (p.inStock) addToCart(p); }} style={s.addBtn(p.inStock)}>
                          {p.inStock ? "+ কার্টে যোগ" : "স্টক নেই"}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}

        {/* CART TAB */}
        {tab === "cart" && (
          <div style={{ padding: "16px" }}>
            <div style={{ fontSize: 18, fontWeight: 800, color: "#1e293b", marginBottom: 16 }}>🛒 আমার কার্ট</div>
            {cart.length === 0 ? (
              <div style={{ textAlign: "center", padding: "60px 20px", color: "#94a3b8" }}>
                <div style={{ fontSize: 60, marginBottom: 12 }}>🛒</div>
                <div style={{ fontSize: 16, fontWeight: 600 }}>কার্ট খালি আছে</div>
                <button onClick={() => setTab("home")} style={{ marginTop: 16, background: "#2563eb", color: "#fff", border: "none", borderRadius: 12, padding: "10px 24px", fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>কেনাকাটা শুরু করুন</button>
              </div>
            ) : (
              <>
                {cart.map(item => (
                  <div key={item.id} style={s.cartItem}>
                    <div style={{ fontSize: 36, background: "#f1f5f9", width: 64, height: 64, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{item.image}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 14, fontWeight: 700, color: "#1e293b", marginBottom: 4 }}>{item.name}</div>
                      <div style={{ fontSize: 15, fontWeight: 800, color: "#1e3a5f", marginBottom: 8 }}>৳{(item.price * item.qty).toLocaleString("bn-BD")}</div>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <button onClick={() => updateQty(item.id, -1)} style={s.qtyBtn}>−</button>
                        <span style={{ fontWeight: 700, fontSize: 15 }}>{item.qty}</span>
                        <button onClick={() => updateQty(item.id, 1)} style={s.qtyBtn}>+</button>
                        <button onClick={() => removeFromCart(item.id)} style={{ marginLeft: "auto", background: "#fef2f2", color: "#dc2626", border: "none", borderRadius: 8, padding: "5px 10px", cursor: "pointer", fontSize: 12, fontFamily: "inherit" }}>সরান</button>
                      </div>
                    </div>
                  </div>
                ))}
                <div style={{ background: "#fff", borderRadius: 14, padding: "14px", marginTop: 8 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 14, color: "#64748b" }}>
                    <span>সাবটোটাল</span><span>৳{cartTotal.toLocaleString("bn-BD")}</span>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 14, color: "#64748b" }}>
                    <span>ডেলিভারি চার্জ</span><span style={{ color: "#16a34a" }}>বিনামূল্যে</span>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", borderTop: "1px solid #f1f5f9", paddingTop: 10, fontSize: 17, fontWeight: 800, color: "#1e293b" }}>
                    <span>মোট</span><span>৳{cartTotal.toLocaleString("bn-BD")}</span>
                  </div>
                </div>
                <button onClick={placeOrder} style={{ width: "100%", marginTop: 12, background: "linear-gradient(135deg, #16a34a, #15803d)", color: "#fff", border: "none", borderRadius: 14, padding: "15px 0", fontSize: 16, fontWeight: 800, cursor: "pointer", fontFamily: "inherit" }}>
                  ✅ অর্ডার দিন
                </button>
              </>
            )}
          </div>
        )}

        {/* WISHLIST TAB */}
        {tab === "wishlist" && (
          <div style={{ padding: "16px" }}>
            <div style={{ fontSize: 18, fontWeight: 800, color: "#1e293b", marginBottom: 16 }}>❤️ আমার উইশলিস্ট</div>
            {wishlist.length === 0 ? (
              <div style={{ textAlign: "center", padding: "60px 20px", color: "#94a3b8" }}>
                <div style={{ fontSize: 60, marginBottom: 12 }}>💝</div>
                <div style={{ fontSize: 16, fontWeight: 600 }}>উইশলিস্ট খালি</div>
                <button onClick={() => setTab("home")} style={{ marginTop: 16, background: "#ef4444", color: "#fff", border: "none", borderRadius: 12, padding: "10px 24px", fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>পণ্য যোগ করুন</button>
              </div>
            ) : (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                {wishlist.map(p => (
                  <div key={p.id} style={s.prodCard}>
                    <div style={{ position: "relative" }}>
                      <div style={s.prodEmoji} onClick={() => setSelectedProduct(p)}>{p.image}</div>
                      <button onClick={() => toggleWishlist(p)} style={{ position: "absolute", top: 8, right: 8, background: "rgba(255,255,255,0.9)", border: "none", borderRadius: "50%", width: 28, height: 28, cursor: "pointer", fontSize: 14 }}>❤️</button>
                    </div>
                    <div style={s.prodInfo}>
                      <div style={{ fontSize: 13, fontWeight: 700, color: "#1e293b", marginBottom: 4 }}>{p.name}</div>
                      <div style={{ fontSize: 15, fontWeight: 800, color: "#1e3a5f", marginBottom: 8 }}>৳{p.price.toLocaleString("bn-BD")}</div>
                      <button onClick={() => { addToCart(p); toggleWishlist(p); }} disabled={!p.inStock} style={s.addBtn(p.inStock)}>
                        {p.inStock ? "কার্টে নিন" : "স্টক নেই"}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ORDERS TAB */}
        {tab === "orders" && (
          <div style={{ padding: "16px" }}>
            <div style={{ fontSize: 18, fontWeight: 800, color: "#1e293b", marginBottom: 16 }}>📦 আমার অর্ডার</div>
            {ORDERS.map(order => (
              <div key={order.id} style={s.orderCard}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: "#1e293b" }}>{order.id}</div>
                    <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 2 }}>{order.date}</div>
                  </div>
                  <span style={{ background: order.statusColor + "20", color: order.statusColor, fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 20 }}>{order.status}</span>
                </div>
                <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: 8 }}>
                  {order.items.map(item => (
                    <div key={item} style={{ fontSize: 13, color: "#475569", marginBottom: 2 }}>• {item}</div>
                  ))}
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 10, borderTop: "1px solid #f1f5f9", paddingTop: 8 }}>
                  <span style={{ fontSize: 15, fontWeight: 800, color: "#1e3a5f" }}>৳{order.total.toLocaleString("bn-BD")}</span>
                  <button style={{ background: "#f1f5f9", color: "#475569", border: "none", borderRadius: 8, padding: "5px 14px", fontSize: 12, cursor: "pointer", fontFamily: "inherit", fontWeight: 600 }}>বিস্তারিত</button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* PROFILE TAB */}
        {tab === "profile" && (
          <div style={{ padding: "16px" }}>
            <div style={{ background: "linear-gradient(135deg, #1e3a5f, #2563eb)", borderRadius: 16, padding: "24px", color: "#fff", textAlign: "center", marginBottom: 16 }}>
              <div style={{ fontSize: 52, marginBottom: 8 }}>👤</div>
              <div style={{ fontSize: 18, fontWeight: 800 }}>রহিম সাহেব</div>
              <div style={{ fontSize: 13, opacity: 0.8, marginTop: 4 }}>rahim@example.com</div>
              <div style={{ fontSize: 12, opacity: 0.7, marginTop: 2 }}>+880 1712-345678</div>
            </div>
            {[
              { icon: "📦", label: "আমার অর্ডার", sub: `${ORDERS.length}টি অর্ডার`, action: () => setTab("orders") },
              { icon: "❤️", label: "উইশলিস্ট", sub: `${wishlist.length}টি পণ্য`, action: () => setTab("wishlist") },
              { icon: "🏠", label: "ডেলিভারি ঠিকানা", sub: "ঢাকা, বাংলাদেশ", action: () => {} },
              { icon: "💳", label: "পেমেন্ট পদ্ধতি", sub: "bKash, কার্ড", action: () => {} },
              { icon: "🔔", label: "নোটিফিকেশন", sub: "চালু আছে", action: () => {} },
              { icon: "🌐", label: "ভাষা", sub: "বাংলা", action: () => {} },
              { icon: "⭐", label: "অ্যাপ রেটিং", sub: "আমাদের রেট করুন", action: () => {} },
            ].map(item => (
              <button key={item.label} onClick={item.action} style={{ width: "100%", background: "#fff", border: "none", borderRadius: 12, padding: "14px 16px", marginBottom: 8, display: "flex", alignItems: "center", gap: 14, cursor: "pointer", textAlign: "left", fontFamily: "inherit" }}>
                <span style={{ fontSize: 24 }}>{item.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: "#1e293b" }}>{item.label}</div>
                  <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 1 }}>{item.sub}</div>
                </div>
                <span style={{ color: "#cbd5e1" }}>›</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Nav */}
      <div style={s.bottomNav}>
        {[
          { id: "home", icon: "🏠", label: "হোম" },
          { id: "search", icon: "🔍", label: "খুঁজুন" },
          { id: "orders", icon: "📦", label: "অর্ডার" },
          { id: "wishlist", icon: "❤️", label: "পছন্দ" },
          { id: "profile", icon: "👤", label: "প্রোফাইল" },
        ].map(nav => (
          <button key={nav.id} onClick={() => setTab(nav.id)} style={s.navBtn(tab === nav.id)}>
            <span style={s.navIcon}>{nav.icon}</span>
            {nav.label}
          </button>
        ))}
      </div>
    </div>
  );
}
