import { useState, useMemo } from "react";

const INIT_PRODUCTS = [
  { id: 1, name: "প্রিমিয়াম কটন পাঞ্জাবি", price: 1200, originalPrice: 1800, category: "পোশাক", rating: 4.5, reviews: 128, image: "👘", badge: "সেরা বিক্রি", inStock: true, stock: 45 },
  { id: 2, name: "স্মার্টফোন কেস", price: 299, originalPrice: 499, category: "ইলেকট্রনিক্স", rating: 4.2, reviews: 89, image: "📱", badge: "নতুন", inStock: true, stock: 120 },
  { id: 3, name: "হ্যান্ডমেড চামড়ার ব্যাগ", price: 3500, originalPrice: 4500, category: "ব্যাগ", rating: 4.8, reviews: 54, image: "👜", badge: "প্রিমিয়াম", inStock: true, stock: 12 },
  { id: 4, name: "বাসমতি চাল ৫ কেজি", price: 650, originalPrice: 750, category: "খাদ্য", rating: 4.6, reviews: 203, image: "🌾", badge: "অফার", inStock: true, stock: 88 },
  { id: 5, name: "ওয়্যারলেস ইয়ারবাড", price: 2200, originalPrice: 3000, category: "ইলেকট্রনিক্স", rating: 4.4, reviews: 167, image: "🎧", badge: "হট ডিল", inStock: true, stock: 34 },
  { id: 6, name: "অর্গানিক নারিকেল তেল", price: 380, originalPrice: 500, category: "সৌন্দর্য", rating: 4.7, reviews: 91, image: "🥥", badge: "অর্গানিক", inStock: false, stock: 0 },
  { id: 7, name: "কিডস স্পোর্টস জুতো", price: 890, originalPrice: 1200, category: "জুতো", rating: 4.3, reviews: 76, image: "👟", badge: "শিশু", inStock: true, stock: 27 },
  { id: 8, name: "ড্রাই ফ্রুট গিফট বক্স", price: 1500, originalPrice: 1800, category: "খাদ্য", rating: 4.9, reviews: 42, image: "🎁", badge: "উপহার", inStock: true, stock: 19 },
];

const INIT_ORDERS = [
  { id: "ORD-001", customer: "রহিম সাহেব", phone: "01712-345678", date: "২০ জুন ২০২৪", status: "ডেলিভারি হয়েছে", total: 3799, items: ["প্রিমিয়াম কটন পাঞ্জাবি", "ওয়্যারলেস ইয়ারবাড"], address: "মিরপুর, ঢাকা" },
  { id: "ORD-002", customer: "করিম ভাই", phone: "01812-567890", date: "১৯ জুন ২০২৪", status: "পথে আছে", total: 1150, items: ["বাসমতি চাল ৫ কেজি"], address: "উত্তরা, ঢাকা" },
  { id: "ORD-003", customer: "সুমাইয়া বেগম", phone: "01912-234567", date: "১৮ জুন ২০২৪", status: "প্রক্রিয়াধীন", total: 890, items: ["কিডস স্পোর্টস জুতো"], address: "মতিঝিল, ঢাকা" },
  { id: "ORD-004", customer: "আলম সাহেব", phone: "01612-789012", date: "১৭ জুন ২০২৪", status: "বাতিল", total: 3500, items: ["হ্যান্ডমেড চামড়ার ব্যাগ"], address: "গুলশান, ঢাকা" },
  { id: "ORD-005", customer: "নাসরিন আক্তার", phone: "01512-345678", date: "১৬ জুন ২০২৪", status: "ডেলিভারি হয়েছে", total: 680, items: ["অর্গানিক নারিকেল তেল", "বাসমতি চাল ৫ কেজি"], address: "বনানী, ঢাকা" },
];

const CATEGORIES = ["পোশাক", "ইলেকট্রনিক্স", "ব্যাগ", "খাদ্য", "সৌন্দর্য", "জুতো", "অন্যান্য"];
const BADGES = ["সেরা বিক্রি", "নতুন", "প্রিমিয়াম", "অফার", "হট ডিল", "অর্গানিক", "শিশু", "উপহার"];
const EMOJIS = ["👘","📱","👜","🌾","🎧","🥥","👟","🎁","👒","🧴","🍎","📚","🖥️","⌚","💄","🧸","🛋️","🎮"];
const STATUS_COLORS = { "ডেলিভারি হয়েছে": "#16a34a", "পথে আছে": "#ea580c", "প্রক্রিয়াধীন": "#7c3aed", "বাতিল": "#dc2626" };

const EMPTY_PRODUCT = { name: "", price: "", originalPrice: "", category: "পোশাক", image: "📦", badge: "নতুন", inStock: true, stock: "" };

export default function AdminDashboard() {
  const [tab, setTab] = useState("dashboard");
  const [products, setProducts] = useState(INIT_PRODUCTS);
  const [orders, setOrders] = useState(INIT_ORDERS);
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [form, setForm] = useState(EMPTY_PRODUCT);
  const [notification, setNotification] = useState(null);
  const [orderFilter, setOrderFilter] = useState("সব");
  const [searchProduct, setSearchProduct] = useState("");
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  const showNotif = (msg, type = "success") => {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 2500);
  };

  // Stats
  const totalRevenue = orders.filter(o => o.status === "ডেলিভারি হয়েছে").reduce((s, o) => s + o.total, 0);
  const totalOrders = orders.length;
  const pendingOrders = orders.filter(o => o.status === "প্রক্রিয়াধীন" || o.status === "পথে আছে").length;
  const lowStock = products.filter(p => p.stock < 20).length;

  const filteredProducts = useMemo(() =>
    products.filter(p => p.name.toLowerCase().includes(searchProduct.toLowerCase())),
    [products, searchProduct]
  );

  const filteredOrders = useMemo(() =>
    orderFilter === "সব" ? orders : orders.filter(o => o.status === orderFilter),
    [orders, orderFilter]
  );

  const openAddModal = () => {
    setEditingProduct(null);
    setForm(EMPTY_PRODUCT);
    setShowProductModal(true);
  };

  const openEditModal = (p) => {
    setEditingProduct(p);
    setForm({ ...p, price: String(p.price), originalPrice: String(p.originalPrice), stock: String(p.stock) });
    setShowProductModal(true);
  };

  const saveProduct = () => {
    if (!form.name || !form.price || !form.stock) { showNotif("সব তথ্য দিন!", "error"); return; }
    const product = {
      ...form,
      price: Number(form.price),
      originalPrice: Number(form.originalPrice || form.price),
      stock: Number(form.stock),
      inStock: Number(form.stock) > 0,
      rating: editingProduct ? editingProduct.rating : 0,
      reviews: editingProduct ? editingProduct.reviews : 0,
    };
    if (editingProduct) {
      setProducts(prev => prev.map(p => p.id === editingProduct.id ? { ...product, id: editingProduct.id } : p));
      showNotif("✅ পণ্য আপডেট হয়েছে");
    } else {
      setProducts(prev => [...prev, { ...product, id: Date.now() }]);
      showNotif("✅ নতুন পণ্য যোগ হয়েছে");
    }
    setShowProductModal(false);
  };

  const deleteProduct = (id) => {
    setProducts(prev => prev.filter(p => p.id !== id));
    setDeleteConfirm(null);
    showNotif("🗑️ পণ্য মুছে ফেলা হয়েছে", "error");
  };

  const updateOrderStatus = (id, status) => {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, status } : o));
    showNotif("✅ অর্ডার স্ট্যাটাস আপডেট হয়েছে");
  };

  const s = {
    app: { maxWidth: 420, margin: "0 auto", minHeight: "100vh", background: "#f1f5f9", fontFamily: "'Hind Siliguri','Noto Sans Bengali',sans-serif", position: "relative" },
    header: { background: "linear-gradient(135deg, #1e3a5f, #2563eb)", padding: "16px 16px 14px", color: "#fff" },
    headerTitle: { fontSize: 18, fontWeight: 800, marginBottom: 2 },
    headerSub: { fontSize: 12, opacity: 0.75 },
    content: { padding: "0 0 80px 0" },
    bottomNav: { position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 420, background: "#fff", borderTop: "1px solid #e2e8f0", display: "flex", justifyContent: "space-around", padding: "8px 0 16px", zIndex: 50 },
    navBtn: (a) => ({ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 2, border: "none", background: "none", cursor: "pointer", color: a ? "#2563eb" : "#94a3b8", fontSize: 10, fontFamily: "inherit", fontWeight: a ? 700 : 400 }),
    card: { background: "#fff", borderRadius: 14, padding: "14px", marginBottom: 10 },
    statCard: (color) => ({ background: color, borderRadius: 14, padding: "14px 16px", color: "#fff", flex: 1 }),
    input: { width: "100%", border: "1px solid #e2e8f0", borderRadius: 10, padding: "10px 12px", fontSize: 14, fontFamily: "inherit", color: "#1e293b", background: "#f8fafc", boxSizing: "border-box", outline: "none" },
    label: { fontSize: 13, fontWeight: 600, color: "#475569", marginBottom: 4, display: "block" },
    btn: (color, text = "#fff") => ({ background: color, color: text, border: "none", borderRadius: 10, padding: "10px 18px", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }),
    modal: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", zIndex: 100, display: "flex", alignItems: "flex-end", justifyContent: "center" },
    modalBox: { background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 420, maxHeight: "90vh", overflowY: "auto", padding: "20px" },
    notif: { position: "fixed", top: 20, left: "50%", transform: "translateX(-50%)", padding: "10px 20px", borderRadius: 30, fontSize: 13, fontWeight: 600, zIndex: 999, whiteSpace: "nowrap", boxShadow: "0 4px 20px rgba(0,0,0,0.2)" },
    tag: (color, bg) => ({ background: bg, color: color, fontSize: 11, fontWeight: 700, padding: "2px 8px", borderRadius: 20 }),
  };

  return (
    <div style={s.app}>
      {/* Notification */}
      {notification && (
        <div style={{ ...s.notif, background: notification.type === "error" ? "#dc2626" : "#1e293b", color: "#fff" }}>
          {notification.msg}
        </div>
      )}

      {/* Header */}
      <div style={s.header}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ background: "rgba(255,255,255,0.2)", borderRadius: 10, width: 38, height: 38, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>⚙️</div>
          <div>
            <div style={s.headerTitle}>BazarBD অ্যাডমিন</div>
            <div style={s.headerSub}>পণ্য ও অর্ডার ম্যানেজমেন্ট</div>
          </div>
        </div>
      </div>

      <div style={s.content}>

        {/* DASHBOARD */}
        {tab === "dashboard" && (
          <div style={{ padding: 16 }}>
            <div style={{ fontSize: 15, fontWeight: 800, color: "#1e293b", marginBottom: 12 }}>📊 সার্বিক পরিসংখ্যান</div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
              <div style={s.statCard("linear-gradient(135deg,#2563eb,#1d4ed8)")}>
                <div style={{ fontSize: 11, opacity: 0.85, marginBottom: 4 }}>মোট আয়</div>
                <div style={{ fontSize: 20, fontWeight: 800 }}>৳{totalRevenue.toLocaleString("bn-BD")}</div>
              </div>
              <div style={s.statCard("linear-gradient(135deg,#16a34a,#15803d)")}>
                <div style={{ fontSize: 11, opacity: 0.85, marginBottom: 4 }}>মোট অর্ডার</div>
                <div style={{ fontSize: 20, fontWeight: 800 }}>{totalOrders}টি</div>
              </div>
              <div style={s.statCard("linear-gradient(135deg,#ea580c,#c2410c)")}>
                <div style={{ fontSize: 11, opacity: 0.85, marginBottom: 4 }}>অপেক্ষমান</div>
                <div style={{ fontSize: 20, fontWeight: 800 }}>{pendingOrders}টি অর্ডার</div>
              </div>
              <div style={s.statCard("linear-gradient(135deg,#7c3aed,#6d28d9)")}>
                <div style={{ fontSize: 11, opacity: 0.85, marginBottom: 4 }}>কম স্টক</div>
                <div style={{ fontSize: 20, fontWeight: 800 }}>{lowStock}টি পণ্য</div>
              </div>
            </div>

            {/* Recent Orders */}
            <div style={{ fontSize: 15, fontWeight: 800, color: "#1e293b", margin: "16px 0 10px" }}>🕐 সাম্প্রতিক অর্ডার</div>
            {orders.slice(0, 3).map(o => (
              <div key={o.id} style={s.card}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 700, color: "#1e293b" }}>{o.customer}</div>
                    <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 2 }}>{o.id} · {o.date}</div>
                  </div>
                  <span style={s.tag(STATUS_COLORS[o.status], STATUS_COLORS[o.status] + "20")}>{o.status}</span>
                </div>
                <div style={{ fontSize: 15, fontWeight: 800, color: "#1e3a5f", marginTop: 8 }}>৳{o.total.toLocaleString("bn-BD")}</div>
              </div>
            ))}

            {/* Low Stock Alert */}
            <div style={{ fontSize: 15, fontWeight: 800, color: "#1e293b", margin: "16px 0 10px" }}>⚠️ কম স্টক সতর্কতা</div>
            {products.filter(p => p.stock < 20).map(p => (
              <div key={p.id} style={{ ...s.card, borderLeft: "3px solid #ea580c" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                    <span style={{ fontSize: 28 }}>{p.image}</span>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: "#1e293b" }}>{p.name}</div>
                      <div style={{ fontSize: 12, color: p.stock === 0 ? "#dc2626" : "#ea580c", fontWeight: 600, marginTop: 2 }}>
                        {p.stock === 0 ? "স্টক শেষ!" : `মাত্র ${p.stock}টি বাকি`}
                      </div>
                    </div>
                  </div>
                  <button onClick={() => openEditModal(p)} style={s.btn("#f1f5f9", "#475569")}>আপডেট</button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* PRODUCTS */}
        {tab === "products" && (
          <div style={{ padding: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <div style={{ fontSize: 15, fontWeight: 800, color: "#1e293b" }}>📦 পণ্য তালিকা ({products.length}টি)</div>
              <button onClick={openAddModal} style={s.btn("#2563eb")}>+ নতুন পণ্য</button>
            </div>

            {/* Search */}
            <div style={{ background: "#fff", borderRadius: 12, padding: "10px 14px", display: "flex", gap: 8, alignItems: "center", marginBottom: 12 }}>
              <span style={{ color: "#94a3b8" }}>🔍</span>
              <input style={{ flex: 1, border: "none", outline: "none", fontSize: 14, fontFamily: "inherit" }}
                placeholder="পণ্য খুঁজুন..."
                value={searchProduct}
                onChange={e => setSearchProduct(e.target.value)} />
            </div>

            {filteredProducts.map(p => (
              <div key={p.id} style={s.card}>
                <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                  <div style={{ fontSize: 36, background: "#f1f5f9", width: 60, height: 60, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{p.image}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                      <div style={{ fontSize: 14, fontWeight: 700, color: "#1e293b", lineHeight: 1.3 }}>{p.name}</div>
                      <span style={s.tag(p.inStock ? "#16a34a" : "#dc2626", p.inStock ? "#dcfce7" : "#fee2e2")}>
                        {p.inStock ? "আছে" : "নেই"}
                      </span>
                    </div>
                    <div style={{ fontSize: 13, color: "#64748b", marginTop: 2 }}>{p.category} · স্টক: {p.stock}টি</div>
                    <div style={{ fontSize: 15, fontWeight: 800, color: "#1e3a5f", marginTop: 4 }}>৳{p.price.toLocaleString("bn-BD")}</div>
                    <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                      <button onClick={() => openEditModal(p)} style={s.btn("#eff6ff", "#2563eb")}>✏️ এডিট</button>
                      <button onClick={() => setDeleteConfirm(p.id)} style={s.btn("#fef2f2", "#dc2626")}>🗑️ মুছুন</button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ORDERS */}
        {tab === "orders" && (
          <div style={{ padding: 16 }}>
            <div style={{ fontSize: 15, fontWeight: 800, color: "#1e293b", marginBottom: 12 }}>📋 অর্ডার ম্যানেজমেন্ট</div>

            {/* Filter */}
            <div style={{ display: "flex", gap: 8, overflowX: "auto", marginBottom: 12, scrollbarWidth: "none" }}>
              {["সব", "প্রক্রিয়াধীন", "পথে আছে", "ডেলিভারি হয়েছে", "বাতিল"].map(f => (
                <button key={f} onClick={() => setOrderFilter(f)} style={{
                  flexShrink: 0, padding: "6px 14px", borderRadius: 20, border: "none", cursor: "pointer",
                  fontSize: 12, fontWeight: orderFilter === f ? 700 : 500, fontFamily: "inherit",
                  background: orderFilter === f ? "#2563eb" : "#fff", color: orderFilter === f ? "#fff" : "#64748b"
                }}>{f}</button>
              ))}
            </div>

            {filteredOrders.map(o => (
              <div key={o.id} style={s.card}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 700, color: "#1e293b" }}>{o.customer}</div>
                    <div style={{ fontSize: 12, color: "#94a3b8" }}>{o.phone}</div>
                    <div style={{ fontSize: 12, color: "#94a3b8" }}>{o.id} · {o.date}</div>
                  </div>
                  <span style={s.tag(STATUS_COLORS[o.status], STATUS_COLORS[o.status] + "20")}>{o.status}</span>
                </div>
                <div style={{ fontSize: 12, color: "#475569", marginBottom: 6 }}>📍 {o.address}</div>
                {o.items.map(item => (
                  <div key={item} style={{ fontSize: 12, color: "#64748b", marginBottom: 2 }}>• {item}</div>
                ))}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 10, borderTop: "1px solid #f1f5f9", paddingTop: 8 }}>
                  <span style={{ fontSize: 15, fontWeight: 800, color: "#1e3a5f" }}>৳{o.total.toLocaleString("bn-BD")}</span>
                  <select
                    value={o.status}
                    onChange={e => updateOrderStatus(o.id, e.target.value)}
                    style={{ border: "1px solid #e2e8f0", borderRadius: 8, padding: "5px 8px", fontSize: 12, fontFamily: "inherit", background: "#fff", color: "#475569" }}
                  >
                    {["প্রক্রিয়াধীন", "পথে আছে", "ডেলিভারি হয়েছে", "বাতিল"].map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* SETTINGS */}
        {tab === "settings" && (
          <div style={{ padding: 16 }}>
            <div style={{ fontSize: 15, fontWeight: 800, color: "#1e293b", marginBottom: 12 }}>⚙️ সেটিংস</div>
            {[
              { icon: "🏪", title: "শপের নাম", sub: "BazarBD" },
              { icon: "📞", title: "যোগাযোগ নম্বর", sub: "01712-345678" },
              { icon: "📍", title: "ঠিকানা", sub: "ঢাকা, বাংলাদেশ" },
              { icon: "💳", title: "পেমেন্ট পদ্ধতি", sub: "bKash, নগদ, কার্ড" },
              { icon: "🚚", title: "ডেলিভারি চার্জ", sub: "বিনামূল্যে (৫০০ টাকার উপরে)" },
              { icon: "🔔", title: "নোটিফিকেশন", sub: "চালু আছে" },
              { icon: "🌐", title: "ভাষা", sub: "বাংলা" },
              { icon: "🔒", title: "পাসওয়ার্ড পরিবর্তন", sub: "শেষবার পরিবর্তন: ১ মাস আগে" },
            ].map(item => (
              <div key={item.title} style={{ ...s.card, display: "flex", alignItems: "center", gap: 14 }}>
                <span style={{ fontSize: 24 }}>{item.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: "#1e293b" }}>{item.title}</div>
                  <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 1 }}>{item.sub}</div>
                </div>
                <span style={{ color: "#cbd5e1", fontSize: 18 }}>›</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Nav */}
      <div style={s.bottomNav}>
        {[
          { id: "dashboard", icon: "📊", label: "ড্যাশবোর্ড" },
          { id: "products", icon: "📦", label: "পণ্য" },
          { id: "orders", icon: "📋", label: "অর্ডার" },
          { id: "settings", icon: "⚙️", label: "সেটিংস" },
        ].map(nav => (
          <button key={nav.id} onClick={() => setTab(nav.id)} style={s.navBtn(tab === nav.id)}>
            <span style={{ fontSize: 22 }}>{nav.icon}</span>
            {nav.label}
          </button>
        ))}
      </div>

      {/* Product Modal */}
      {showProductModal && (
        <div style={s.modal} onClick={e => e.target === e.currentTarget && setShowProductModal(false)}>
          <div style={s.modalBox}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ fontSize: 16, fontWeight: 800, color: "#1e293b" }}>{editingProduct ? "পণ্য এডিট করুন" : "নতুন পণ্য যোগ করুন"}</div>
              <button onClick={() => setShowProductModal(false)} style={{ background: "#f1f5f9", border: "none", borderRadius: "50%", width: 32, height: 32, cursor: "pointer", fontSize: 16 }}>✕</button>
            </div>

            {/* Emoji picker */}
            <div style={{ marginBottom: 14 }}>
              <label style={s.label}>পণ্যের ছবি (ইমোজি)</label>
              <button onClick={() => setShowEmojiPicker(!showEmojiPicker)} style={{ background: "#f8fafc", border: "1px solid #e2e8f0", borderRadius: 10, padding: "8px 16px", fontSize: 28, cursor: "pointer" }}>{form.image}</button>
              {showEmojiPicker && (
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 8, background: "#f8fafc", borderRadius: 12, padding: 10 }}>
                  {EMOJIS.map(e => (
                    <button key={e} onClick={() => { setForm(f => ({ ...f, image: e })); setShowEmojiPicker(false); }}
                      style={{ fontSize: 26, background: form.image === e ? "#dbeafe" : "transparent", border: "none", borderRadius: 8, cursor: "pointer", padding: 4 }}>{e}</button>
                  ))}
                </div>
              )}
            </div>

            <div style={{ marginBottom: 12 }}>
              <label style={s.label}>পণ্যের নাম *</label>
              <input style={s.input} placeholder="যেমন: কটন শাড়ি" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
              <div>
                <label style={s.label}>বিক্রয় মূল্য (৳) *</label>
                <input style={s.input} type="number" placeholder="১২০০" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} />
              </div>
              <div>
                <label style={s.label}>আসল মূল্য (৳)</label>
                <input style={s.input} type="number" placeholder="১৮০০" value={form.originalPrice} onChange={e => setForm(f => ({ ...f, originalPrice: e.target.value }))} />
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
              <div>
                <label style={s.label}>ক্যাটাগরি</label>
                <select style={s.input} value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
                  {CATEGORIES.map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label style={s.label}>ব্যাজ</label>
                <select style={s.input} value={form.badge} onChange={e => setForm(f => ({ ...f, badge: e.target.value }))}>
                  {BADGES.map(b => <option key={b}>{b}</option>)}
                </select>
              </div>
            </div>

            <div style={{ marginBottom: 16 }}>
              <label style={s.label}>স্টক পরিমাণ *</label>
              <input style={s.input} type="number" placeholder="৫০" value={form.stock} onChange={e => setForm(f => ({ ...f, stock: e.target.value }))} />
            </div>

            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => setShowProductModal(false)} style={{ ...s.btn("#f1f5f9", "#475569"), flex: 1 }}>বাতিল</button>
              <button onClick={saveProduct} style={{ ...s.btn("#2563eb"), flex: 2 }}>{editingProduct ? "✅ আপডেট করুন" : "✅ যোগ করুন"}</button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirm */}
      {deleteConfirm && (
        <div style={s.modal}>
          <div style={{ ...s.modalBox, padding: "24px" }}>
            <div style={{ textAlign: "center", marginBottom: 16 }}>
              <div style={{ fontSize: 48, marginBottom: 8 }}>🗑️</div>
              <div style={{ fontSize: 16, fontWeight: 800, color: "#1e293b", marginBottom: 4 }}>পণ্য মুছে ফেলবেন?</div>
              <div style={{ fontSize: 13, color: "#64748b" }}>এই কাজটি আর ফিরিয়ে আনা যাবে না</div>
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => setDeleteConfirm(null)} style={{ ...s.btn("#f1f5f9", "#475569"), flex: 1 }}>বাতিল</button>
              <button onClick={() => deleteProduct(deleteConfirm)} style={{ ...s.btn("#dc2626"), flex: 1 }}>হ্যাঁ, মুছুন</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
